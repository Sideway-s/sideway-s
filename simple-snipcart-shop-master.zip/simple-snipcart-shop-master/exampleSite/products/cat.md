+++
name = "Cat"
price = 10
image = "/images/collage-1.jpg"
description = "This is a silly little cat"
sizes = ["Small", "Medium", "Large"]
+++
